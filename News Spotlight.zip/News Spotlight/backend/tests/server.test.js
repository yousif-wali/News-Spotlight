const request = require('supertest');
const app = require('../server.cjs');

describe('Checking if the server is up and working', () => {
  it('should return 200 OK', async () => {
    const res = await request(app).get('/');
    expect(res.statusCode).toEqual(200);
  });
});

describe('Checking if the news API works', () => {
  it('should return a non-empty JSON object', async () => {
    function isJsonAndNotEmpty(data) {
      try {
        // Check if the data is already an object
        if (typeof data === 'object' && data !== null) {
          return Object.keys(data).length > 0;
        }

        // Try parsing the data if it's a string
        const jsonData = JSON.parse(data);

        // Check if it's an object or array and not empty
        if (jsonData && typeof jsonData === 'object' && Object.keys(jsonData).length > 0) {
          return true; // It's JSON and not empty
        }

        // Additional check for arrays, if needed
        if (Array.isArray(jsonData) && jsonData.length > 0) {
          return true;
        }

        return false; 
      } catch (e) {
        return false;
      }
    }

    const res = await request(app).get('/api/news');
    expect(res.statusCode).toEqual(200); // Ensure the status code is 200
    expect(isJsonAndNotEmpty(res.body)).toBe(true); // Ensure the response body is a non-empty JSON object
  });
});
