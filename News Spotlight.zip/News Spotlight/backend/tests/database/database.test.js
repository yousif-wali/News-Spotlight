jest.mock('./../../database.cjs', () => {
  return {
    all: jest.fn((query, params, callback) => {
      const sampleData = [
        { id: 1, title: 'Test News', description: 'This is a test', url: 'http://test.com', source: 'Test Source', publishedAt: '2023-01-01' },
      ];
      callback(null, sampleData); // Simulate a successful query with sample data
    }),
  };
});

const db = require("./../../database.cjs");

describe("Checking if database is working", () => {
  function GetData() {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM news', [], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows.length > 0);
        }
      });
    });
  }

  it('should return true', async () => {
    const result = await GetData();
    expect(result).toBe(true);
  });
});
