const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const cron = require('node-cron');
const axios = require('axios');
const app = express();
const db = require('./database.cjs');

app.use(bodyParser.json());
app.use(cors());

// Load the root page
app.get('/', (req, res) => {
  res.sendStatus(200);
});

// Function to fetch news from NewsAPI
const fetchNewsFromAPI = async (source) => {
  try {
    const response = await axios.get('https://newsapi.org/v2/top-headlines', {
      params: {
        apiKey: '5019d2ee9c5b421c8532dc669605924a',
        sources: source,
        pageSize: 20,
      }
    });

    const articles = response.data.articles;
    articles.forEach(article => {
      db.run(
        `INSERT INTO news (title, description, url, source, publishedAt, imageurl, content) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [article.title, article.description, article.url, article.source.name, article.publishedAt, article.urlToImage, article.content],
        (err) => {
          if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
              console.log(`Duplicate article title found: "${article.title}"`);
            } else {
              console.error('Error inserting article:', err.message);
            }
          }
        }
      );
    });

    console.log('News articles fetched and stored in the database.');
  } catch (error) {
    console.error('Error fetching news:', error.message);
  }
};

// Schedule the API calls
const sources = [
  'cnn',
  'bbc-news',
  'cbs-news',
  'associated-press',
  'fox-news',
  'usa-today',
  'the-verge'
];

sources.forEach((source, index) => {
  cron.schedule(`*/605 * * * * *`, () => fetchNewsFromAPI(source));
});

// API route to get news from the database
app.get('/api/news', (req, res) => {
  db.all('SELECT * FROM news ORDER BY publishedAt DESC', [], (err, rows) => {
    if (err) {
      res.status(400).json({ error: err.message });
      return;
    }
    res.json({ data: rows });
  });
});

module.exports = app;
