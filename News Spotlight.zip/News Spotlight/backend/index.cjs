const app = require('./server.cjs');
const PORT = process.env.PORT || 2999;


app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
