import './App.css';
import { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [data, setData] = useState([]);
  const [filtered, setFiltered] = useState([]);

  useEffect(() => {
    const LoadData = async () => {
      try {
        const response = await axios.get('http://localhost:2999/api/news');
        setData(response.data.data);
        setFiltered(response.data.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    LoadData();
  }, []);

  const formatDate = (dateString) => {
    const options = {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    };

    const date = new Date(dateString);
    return date.toLocaleString('en-US', options);
  };

  const filteringSource = (e) => {
    const source = e.target.getAttribute("name");
    const filters = document.getElementsByClassName("filter")
    try{
      for(let i = 0; i < filters.length; i++){
        filters[i].classList.remove("active")
      }
    }catch{

    }
    e.target.classList.add("active")
    if(source === "All-Sources"){
      setFiltered(data);
      return;
    }
    console.log()
    const filteredData = data.filter(item => item.source === source);
    setFiltered(filteredData);
  };
  const sort = ()=>{
    setFiltered([...filtered].reverse());
  }

  return (
    <div className="App">
      <section style={{borderBottom: "1px solid black"}}>
        <h1 className='ms-2 mt-2'>Welcome to my news app</h1>
        <h4 className='ms-2'>Here you would get the most updated news</h4>
      </section>
      <h4 className='ms-2 pt-3'>Sources</h4>
      <section className='d-flex'>
        
        <section name="All-Sources" onClick={filteringSource} className='filter active'>
          All
        </section>
        <section name="CNN" onClick={filteringSource} className='filter'>
          CNN
        </section>
        <section name="BBC News" onClick={filteringSource} className='filter'>
          BBC News
        </section>
        <section name="CBS News" onClick={filteringSource} className='filter'>
          CBS News
        </section>
        <section name="Associated Press" onClick={filteringSource} className='filter'>
          Associated Press
        </section>
        <section name="Fox News" onClick={filteringSource} className='filter'>
          Fox News
        </section>
        <section name="USA Today" onClick={filteringSource} className='filter'>
          USA Today
        </section>
        <section name="The Verge" onClick={filteringSource} className='filter'>
          The Verge
        </section>
        <section className='d-flex align-items-center justify-content-center'>
          <h4>Sort</h4>
          <select className='ms-2' onChange={sort}>
            <option value="newest">Newest first</option>
            <option value="oldest">Oldest first</option>
          </select>
        </section>
      </section>
      <section className='ms-2'>
        Total News: {filtered.length}
      </section>
      <section className='row'>
        {
          filtered.length > 0 ? (
            filtered.map((item, index) => (
              <div key={index} className="card d-flex ms-auto me-auto mt-2 mb-2" style={{ width: "400px" }}>
                <img src={item.imageurl} className="card-img-top" alt="Visit the site to see more images" style={{ height: "200px" }} />
                <span>{formatDate(item.publishedAt)}</span>
                <div className="card-body">
                  <h5 className="card-title">{item.title}</h5>
                  <p className="card-text">{item.content}</p>
                  <a href={item.url} className="btn btn-primary" target="_blank" rel="noopener noreferrer">See more...</a>
                </div>
              </div>
            ))
          ) : (
            <p>No articles available</p>
          )
        }
      </section>
    </div>
  );
}

export default App;
